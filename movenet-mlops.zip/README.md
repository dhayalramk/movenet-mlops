# MoveNet MLOps Project

This project deploys Google's MoveNet pose estimation model using FastAPI backend and a TensorFlow.js frontend with CI/CD and monitoring.